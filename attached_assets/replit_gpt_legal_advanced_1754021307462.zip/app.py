
from flask import Flask, request, jsonify
from ai_analyzer import analyze_document

app = Flask(__name__)

@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        data = request.get_json()
        document_text = data.get("text", "")
        if not document_text:
            return jsonify({"error": "Documentul lipsește"}), 400

        result = analyze_document(document_text)
        return jsonify({"result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
