
import openai
import time
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def fetch_gpt_analysis(messages, retries=3, timeout=120, stream=False):
    for attempt in range(retries):
        try:
            return openai.ChatCompletion.create(
                model="gpt-4",
                messages=messages,
                timeout=timeout,
                stream=stream
            )
        except Exception as e:
            print(f"[GPT] Încercarea {attempt+1} eșuată: {e}")
            time.sleep(5 * (2 ** attempt))
    raise Exception("❌ GPT API nu a răspuns după toate încercările.")

def analyze_document(document_text):
    messages = [
        {"role": "system", "content": "Ești un avocat AI specializat în analiza documentelor legale."},
        {"role": "user", "content": f"Analizează documentul de mai jos și oferă: tipul documentului, clauze cheie, riscuri, recomandări, rezumat.\n\nDOCUMENT:\n{document_text}"}
    ]
    response = fetch_gpt_analysis(messages)
    return response["choices"][0]["message"]["content"]
